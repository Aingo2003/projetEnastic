// Database utilities using Trickle API

async function saveUserToDB(userData) {
  try {
    // Check if user already exists
    const users = await trickleListObjects('user', 10, true);
    const existingUser = users.items.find(u => u.objectData.email === userData.email);
    
    if (existingUser) {
      return existingUser;
    }
    
    // Create new user
    const userObj = {
      firstName: userData.firstName,
      lastName: userData.lastName,
      email: userData.email,
      profilePhoto: userData.profilePhoto || '',
      location: userData.location || '',
      joinDate: new Date().toISOString()
    };
    
    return await trickleCreateObject('user', userObj);
  } catch (error) {
    console.error('Error saving user to database:', error);
    throw error;
  }
}

async function getUserFromDB(email) {
  try {
    const users = await trickleListObjects('user', 50, true);
    return users.items.find(u => u.objectData.email === email);
  } catch (error) {
    console.error('Error getting user from database:', error);
    return null;
  }
}

async function saveMessageToDB(messageData) {
  try {
    return await trickleCreateObject('message', messageData);
  } catch (error) {
    console.error('Error saving message:', error);
    throw error;
  }
}

async function getMessagesForUser(userEmail) {
  try {
    const messages = await trickleListObjects('message', 100, true);
    return messages.items.filter(m => 
      m.objectData.toUser === userEmail || m.objectData.fromUser === userEmail
    );
  } catch (error) {
    console.error('Error getting messages:', error);
    return [];
  }
}

async function markMessageAsRead(messageId) {
  try {
    const message = await trickleGetObject('message', messageId);
    return await trickleUpdateObject('message', messageId, {
      ...message.objectData,
      isRead: true
    });
  } catch (error) {
    console.error('Error marking message as read:', error);
  }
}

async function saveGroupToDB(groupData) {
  try {
    return await trickleCreateObject('group', groupData);
  } catch (error) {
    console.error('Error saving group:', error);
    throw error;
  }
}

async function getGroupsFromDB() {
  try {
    const groups = await trickleListObjects('group', 50, true);
    return groups.items;
  } catch (error) {
    console.error('Error getting groups:', error);
    return [];
  }
}
