// Local storage utilities for user data management

function saveUser(userData) {
  try {
    localStorage.setItem('ecowatch_user', JSON.stringify(userData));
  } catch (error) {
    console.error('Error saving user data:', error);
  }
}

function getStoredUser() {
  try {
    const userData = localStorage.getItem('ecowatch_user');
    return userData ? JSON.parse(userData) : null;
  } catch (error) {
    console.error('Error retrieving user data:', error);
    return null;
  }
}

function removeUser() {
  try {
    localStorage.removeItem('ecowatch_user');
  } catch (error) {
    console.error('Error removing user data:', error);
  }
}

function saveEvents(events) {
  try {
    localStorage.setItem('ecowatch_events', JSON.stringify(events));
  } catch (error) {
    console.error('Error saving events:', error);
  }
}

function getStoredEvents() {
  try {
    const events = localStorage.getItem('ecowatch_events');
    return events ? JSON.parse(events) : [];
  } catch (error) {
    console.error('Error retrieving events:', error);
    return [];
  }
}

function savePractices(practices) {
  try {
    localStorage.setItem('ecowatch_practices', JSON.stringify(practices));
  } catch (error) {
    console.error('Error saving practices:', error);
  }
}

function getStoredPractices() {
  try {
    const practices = localStorage.getItem('ecowatch_practices');
    return practices ? JSON.parse(practices) : [];
  } catch (error) {
    console.error('Error retrieving practices:', error);
    return [];
  }
}