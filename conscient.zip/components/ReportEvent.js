function ReportEvent({ onAddEvent }) {
  try {
    const [formData, setFormData] = React.useState({
      type: '',
      location: '',
      description: '',
      latitude: '',
      longitude: ''
    });

    const [showSuccess, setShowSuccess] = React.useState(false);

    const eventTypes = [
      'Désertification',
      'Inondation',
      'Érosion',
      'Sécheresse',
      'Déforestation',
      'Pollution',
      'Autre'
    ];

    const handleSubmit = (e) => {
      e.preventDefault();
      onAddEvent({
        ...formData,
        lat: parseFloat(formData.latitude) || 0,
        lng: parseFloat(formData.longitude) || 0
      });
      
      setFormData({
        type: '',
        location: '',
        description: '',
        latitude: '',
        longitude: ''
      });
      
      setShowSuccess(true);
      setTimeout(() => setShowSuccess(false), 3000);
    };

    const handleChange = (e) => {
      setFormData(prev => ({
        ...prev,
        [e.target.name]: e.target.value
      }));
    };

    const getCurrentLocation = async () => {
      try {
        const position = await getCurrentPosition();
        const address = await getAddressFromCoordinates(position.latitude, position.longitude);
        
        setFormData(prev => ({
          ...prev,
          latitude: position.latitude.toString(),
          longitude: position.longitude.toString(),
          location: address.fullAddress
        }));
        
        alert('Position détectée automatiquement!');
      } catch (error) {
        console.error('Erreur de géolocalisation:', error);
        alert('Impossible de détecter votre position: ' + error.message);
      }
    };

    return (
      <div className="max-w-2xl mx-auto" data-name="report-event" data-file="components/ReportEvent.js">
        <div className="card">
          <div className="flex items-center space-x-3 mb-6">
            <div className="icon-alert-triangle text-2xl text-orange-600"></div>
            <h2 className="text-2xl font-bold text-gray-800">Signaler un Événement Climatique</h2>
          </div>

          {showSuccess && (
            <div className="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-6">
              <div className="flex items-center space-x-2">
                <div className="icon-check-circle text-lg"></div>
                <span>Événement signalé avec succès ! Merci pour votre contribution.</span>
              </div>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Type d'événement</label>
              <select
                name="type"
                value={formData.type}
                onChange={handleChange}
                className="input-field"
                required
              >
                <option value="">Sélectionnez un type</option>
                {eventTypes.map(type => (
                  <option key={type} value={type}>{type}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Localisation</label>
              <input
                type="text"
                name="location"
                value={formData.location}
                onChange={handleChange}
                className="input-field"
                placeholder="Ville, Région, Pays"
                required
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Latitude</label>
                <input
                  type="number"
                  name="latitude"
                  value={formData.latitude}
                  onChange={handleChange}
                  className="input-field"
                  step="any"
                  placeholder="Ex: 14.7167"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Longitude</label>
                <input
                  type="number"
                  name="longitude"
                  value={formData.longitude}
                  onChange={handleChange}
                  className="input-field"
                  step="any"
                  placeholder="Ex: -17.4677"
                />
              </div>
            </div>

            <button
              type="button"
              onClick={getCurrentLocation}
              className="btn-secondary flex items-center space-x-2"
            >
              <div className="icon-map-pin text-lg"></div>
              <span>Utiliser ma position actuelle</span>
            </button>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Description détaillée</label>
              <textarea
                name="description"
                value={formData.description}
                onChange={handleChange}
                className="input-field h-32 resize-none"
                placeholder="Décrivez l'événement observé, ses impacts, sa gravité..."
                required
              ></textarea>
            </div>

            <button type="submit" className="btn-primary w-full">
              Signaler l'Événement
            </button>
          </form>
        </div>
      </div>
    );
  } catch (error) {
    console.error('ReportEvent component error:', error);
    return null;
  }
}