function Messaging({ user }) {
  try {
    const [messages, setMessages] = React.useState([]);
    const [users, setUsers] = React.useState([]);
    const [showCompose, setShowCompose] = React.useState(false);
    const [selectedMessage, setSelectedMessage] = React.useState(null);
    const [newMessage, setNewMessage] = React.useState({
      toUser: '',
      subject: '',
      content: '',
      projectType: ''
    });

    React.useEffect(() => {
      loadMessages();
      loadUsers();
    }, [user]);

    const loadMessages = async () => {
      try {
        const userMessages = await getMessagesForUser(user.email);
        setMessages(userMessages);
      } catch (error) {
        console.error('Error loading messages:', error);
      }
    };

    const loadUsers = async () => {
      try {
        const result = await trickleListObjects('user', 50, true);
        setUsers(result.items.filter(u => u.objectData.email !== user.email));
      } catch (error) {
        console.error('Error loading users:', error);
      }
    };

    const sendMessage = async (e) => {
      e.preventDefault();
      try {
        const messageData = {
          fromUser: user.email,
          toUser: newMessage.toUser,
          subject: newMessage.subject,
          content: newMessage.content,
          sentDate: new Date().toISOString(),
          isRead: false,
          projectType: newMessage.projectType
        };

        await saveMessageToDB(messageData);
        setNewMessage({ toUser: '', subject: '', content: '', projectType: '' });
        setShowCompose(false);
        loadMessages();
        
        // Send email notification simulation
        alert(`Message envoyé à ${newMessage.toUser} avec notification email!`);
      } catch (error) {
        console.error('Error sending message:', error);
      }
    };

    const handleMessageClick = async (message) => {
      setSelectedMessage(message);
      if (!message.objectData.isRead && message.objectData.toUser === user.email) {
        await markMessageAsRead(message.objectId);
        loadMessages();
      }
    };

    const projectTypes = ['Reforestation', 'Nettoyage', 'Sensibilisation', 'Recherche', 'Protection', 'Autre'];

    return (
      <div className="max-w-6xl mx-auto space-y-6" data-name="messaging" data-file="components/Messaging.js">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Messages List */}
          <div className="lg:col-span-1 card">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-bold text-gray-800">Messages</h2>
              <button
                onClick={() => setShowCompose(!showCompose)}
                className="btn-primary flex items-center space-x-2"
              >
                <div className="icon-plus text-sm"></div>
                <span>Nouveau</span>
              </button>
            </div>

            <div className="space-y-2 max-h-96 overflow-y-auto">
              {messages.map(message => (
                <div
                  key={message.objectId}
                  onClick={() => handleMessageClick(message)}
                  className={`p-3 rounded-lg cursor-pointer border ${
                    selectedMessage?.objectId === message.objectId
                      ? 'bg-blue-50 border-blue-200'
                      : 'bg-gray-50 border-gray-200 hover:bg-gray-100'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-medium text-sm">
                      {message.objectData.fromUser === user.email ? 'À: ' : 'De: '}
                      {message.objectData.fromUser === user.email 
                        ? message.objectData.toUser 
                        : message.objectData.fromUser}
                    </span>
                    {!message.objectData.isRead && message.objectData.toUser === user.email && (
                      <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                    )}
                  </div>
                  <p className="text-sm text-gray-700 truncate">{message.objectData.subject}</p>
                  <p className="text-xs text-gray-500">
                    {new Date(message.objectData.sentDate).toLocaleDateString()}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Message Content or Compose */}
          <div className="lg:col-span-2 card">
            {showCompose ? (
              <div>
                <h3 className="text-lg font-bold mb-4">Nouveau Message</h3>
                <form onSubmit={sendMessage} className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium mb-1">Destinataire</label>
                    <select
                      value={newMessage.toUser}
                      onChange={(e) => setNewMessage(prev => ({...prev, toUser: e.target.value}))}
                      className="input-field"
                      required
                    >
                      <option value="">Sélectionner un utilisateur</option>
                      {users.map(u => (
                        <option key={u.objectId} value={u.objectData.email}>
                          {u.objectData.firstName} {u.objectData.lastName}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Type de projet</label>
                    <select
                      value={newMessage.projectType}
                      onChange={(e) => setNewMessage(prev => ({...prev, projectType: e.target.value}))}
                      className="input-field"
                    >
                      <option value="">Sélectionner un type</option>
                      {projectTypes.map(type => (
                        <option key={type} value={type}>{type}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Sujet</label>
                    <input
                      type="text"
                      value={newMessage.subject}
                      onChange={(e) => setNewMessage(prev => ({...prev, subject: e.target.value}))}
                      className="input-field"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">Message</label>
                    <textarea
                      value={newMessage.content}
                      onChange={(e) => setNewMessage(prev => ({...prev, content: e.target.value}))}
                      className="input-field h-32"
                      required
                    ></textarea>
                  </div>
                  <div className="flex space-x-3">
                    <button type="submit" className="btn-primary">Envoyer</button>
                    <button
                      type="button"
                      onClick={() => setShowCompose(false)}
                      className="btn-secondary"
                    >
                      Annuler
                    </button>
                  </div>
                </form>
              </div>
            ) : selectedMessage ? (
              <div>
                <div className="border-b pb-4 mb-4">
                  <h3 className="text-lg font-bold">{selectedMessage.objectData.subject}</h3>
                  <div className="text-sm text-gray-600 mt-1">
                    De: {selectedMessage.objectData.fromUser} | 
                    Projet: {selectedMessage.objectData.projectType} | 
                    {new Date(selectedMessage.objectData.sentDate).toLocaleString()}
                  </div>
                </div>
                <div className="text-gray-700 whitespace-pre-wrap">
                  {selectedMessage.objectData.content}
                </div>
              </div>
            ) : (
              <div className="text-center py-12 text-gray-500">
                <div className="icon-mail text-4xl mb-2"></div>
                <p>Sélectionnez un message pour le lire</p>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  } catch (error) {
    console.error('Messaging component error:', error);
    return null;
  }
}