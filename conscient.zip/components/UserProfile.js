function UserProfile({ user }) {
  try {
    return (
      <div className="card" data-name="user-profile" data-file="components/UserProfile.js">
        <h2 className="text-xl font-bold mb-4 text-gray-800">Mon Profil</h2>
        
        <div className="flex items-center space-x-4 mb-6">
          <img 
            src={user.profilePhoto || 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=80&h=80&fit=crop&crop=face'} 
            alt="Photo de profil" 
            className="w-16 h-16 rounded-full border-2 border-green-200"
          />
          <div>
            <h3 className="text-lg font-semibold text-gray-800">
              {user.firstName} {user.lastName}
            </h3>
            <p className="text-gray-600">{user.email}</p>
          </div>
        </div>

        <div className="space-y-3">
          <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
            <div className="flex items-center space-x-3">
              <div className="icon-alert-triangle text-lg text-orange-600"></div>
              <span className="text-sm text-gray-700">Signalements effectués</span>
            </div>
            <span className="font-semibold text-gray-800">3</span>
          </div>
          
          <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
            <div className="flex items-center space-x-3">
              <div className="icon-lightbulb text-lg text-yellow-600"></div>
              <span className="text-sm text-gray-700">Bonnes pratiques partagées</span>
            </div>
            <span className="font-semibold text-gray-800">2</span>
          </div>
          
          <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
            <div className="flex items-center space-x-3">
              <div className="icon-heart text-lg text-red-600"></div>
              <span className="text-sm text-gray-700">Contributions appréciées</span>
            </div>
            <span className="font-semibold text-gray-800">15</span>
          </div>
        </div>

        <div className="mt-6 p-4 bg-green-50 rounded-lg">
          <div className="flex items-center space-x-2 mb-2">
            <div className="icon-award text-lg text-green-600"></div>
            <span className="text-sm font-medium text-green-700">Niveau Éco-Citoyen</span>
          </div>
          <div className="w-full bg-green-200 rounded-full h-2">
            <div className="bg-green-500 h-2 rounded-full" style={{width: '60%'}}></div>
          </div>
          <p className="text-xs text-green-600 mt-1">60% vers le niveau suivant</p>
        </div>
      </div>
    );
  } catch (error) {
    console.error('UserProfile component error:', error);
    return null;
  }
}