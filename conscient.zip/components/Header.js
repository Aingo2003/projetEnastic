function Header({ user, currentPage, setCurrentPage, onLogout, isAdmin }) {
  try {
    const [showMobileMenu, setShowMobileMenu] = React.useState(false);

    const menuItems = [
      { key: 'dashboard', label: 'Tableau de bord', icon: 'home' },
      { key: 'report', label: 'Signaler', icon: 'alert-triangle' },
      { key: 'map', label: 'Carte', icon: 'map' },
      { key: 'practices', label: 'Bonnes pratiques', icon: 'lightbulb' },
      { key: 'recommendations', label: 'Recommandations IA', icon: 'brain' },
      { key: 'messages', label: 'Messages', icon: 'mail' },
      { key: 'notifications', label: 'Notifications', icon: 'bell' },
      { key: 'community', label: 'Communauté', icon: 'users' }
    ];

    const adminItems = [
      { key: 'admin', label: 'Admin', icon: 'shield' },
      { key: 'analytics', label: 'Analytics', icon: 'bar-chart' },
      { key: 'reports', label: 'Rapports', icon: 'file-text' }
    ];

    return (
      <header className="bg-white shadow-md" data-name="header" data-file="components/Header.js">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="icon-leaf text-xl sm:text-2xl text-green-600"></div>
              <h1 className="text-xl sm:text-2xl font-bold text-green-700">EcoWatch</h1>
            </div>
            
            {user && (
              <>
                {/* Desktop Navigation */}
                <nav className="hidden lg:flex items-center space-x-4">
                  {menuItems.map(item => (
                    <button
                      key={item.key}
                      onClick={() => setCurrentPage(item.key)}
                      className={`px-2 py-1 text-xs rounded-md ${currentPage === item.key ? 'bg-green-100 text-green-700' : 'text-gray-600 hover:text-green-600'}`}
                    >
                      {item.label}
                    </button>
                  ))}
                  {isAdmin && adminItems.map(item => (
                    <button
                      key={item.key}
                      onClick={() => setCurrentPage(item.key)}
                      className={`px-2 py-1 text-xs rounded-md ${currentPage === item.key ? 'bg-blue-100 text-blue-700' : 'text-gray-600 hover:text-blue-600'}`}
                    >
                      {item.label}
                    </button>
                  ))}
                </nav>

                {/* Mobile Menu Button */}
                <button
                  className="lg:hidden"
                  onClick={() => setShowMobileMenu(true)}
                >
                  <div className="icon-menu text-xl"></div>
                </button>
              </>
            )}
            
            {user && (
              <div className="flex items-center space-x-2 sm:space-x-4">
                <div className="flex items-center space-x-2">
                  <img 
                    src={user.profilePhoto || 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=40&h=40&fit=crop&crop=face'} 
                    alt="Profile" 
                    className="w-6 h-6 sm:w-8 sm:h-8 rounded-full"
                  />
                  <span className="hidden sm:block text-sm font-medium text-gray-700">{user.firstName}</span>
                </div>
                <button
                  onClick={onLogout}
                  className="text-gray-500 hover:text-red-600"
                >
                  <div className="icon-log-out text-lg"></div>
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Mobile Menu */}
        {showMobileMenu && (
          <div className="mobile-nav" onClick={() => setShowMobileMenu(false)}>
            <div className="mobile-menu" onClick={(e) => e.stopPropagation()}>
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-lg font-semibold">Menu</h2>
                <button onClick={() => setShowMobileMenu(false)}>
                  <div className="icon-x text-lg"></div>
                </button>
              </div>
              <nav className="space-y-2">
                {menuItems.map(item => (
                  <button
                    key={item.key}
                    onClick={() => {
                      setCurrentPage(item.key);
                      setShowMobileMenu(false);
                    }}
                    className={`w-full text-left px-3 py-2 rounded-md flex items-center space-x-2 ${currentPage === item.key ? 'bg-green-100 text-green-700' : 'text-gray-600 hover:bg-gray-100'}`}
                  >
                    <div className={`icon-${item.icon} text-lg`}></div>
                    <span>{item.label}</span>
                  </button>
                ))}
                {isAdmin && adminItems.map(item => (
                  <button
                    key={item.key}
                    onClick={() => {
                      setCurrentPage(item.key);
                      setShowMobileMenu(false);
                    }}
                    className={`w-full text-left px-3 py-2 rounded-md flex items-center space-x-2 ${currentPage === item.key ? 'bg-blue-100 text-blue-700' : 'text-gray-600 hover:bg-gray-100'}`}
                  >
                    <div className={`icon-${item.icon} text-lg`}></div>
                    <span>{item.label}</span>
                  </button>
                ))}
              </nav>
            </div>
          </div>
        )}
      </header>
    );
  } catch (error) {
    console.error('Header component error:', error);
    return null;
  }
}
