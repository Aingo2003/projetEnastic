function Reports({ events, practices }) {
  try {
    const [reportType, setReportType] = React.useState('events');
    const [dateRange, setDateRange] = React.useState('month');
    const [generating, setGenerating] = React.useState(false);

    const generateReport = async () => {
      setGenerating(true);
      try {
        // Simulate report generation
        await new Promise(resolve => setTimeout(resolve, 2000));
        
        const reportData = {
          events: events.length,
          practices: practices.length,
          regions: new Set(events.map(e => e.location.split(',')[0])).size,
          criticalEvents: events.filter(e => e.severity === 'Critique').length,
          dateRange: dateRange,
          generatedAt: new Date().toISOString()
        };

        // Create downloadable content
        const reportContent = `
RAPPORT ENVIRONNEMENTAL ECOWATCH
================================

Période: ${dateRange === 'week' ? 'Dernière semaine' : dateRange === 'month' ? 'Dernier mois' : 'Dernière année'}
Généré le: ${new Date().toLocaleString()}

STATISTIQUES GÉNÉRALES
======================
- Total événements signalés: ${reportData.events}
- Bonnes pratiques partagées: ${reportData.practices}
- Régions couvertes: ${reportData.regions}
- Événements critiques: ${reportData.criticalEvents}

DÉTAIL DES ÉVÉNEMENTS
====================
${events.slice(0, 10).map(e => `- ${e.type} à ${e.location} (${e.date})`).join('\n')}

BONNES PRATIQUES POPULAIRES
===========================
${practices.slice(0, 5).map(p => `- ${p.title} par ${p.author}`).join('\n')}
        `;

        // Download as text file
        const blob = new Blob([reportContent], { type: 'text/plain' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `rapport-ecowatch-${new Date().toISOString().split('T')[0]}.txt`;
        a.click();
        window.URL.revokeObjectURL(url);

        alert('Rapport généré et téléchargé avec succès!');
      } catch (error) {
        console.error('Error generating report:', error);
        alert('Erreur lors de la génération du rapport');
      } finally {
        setGenerating(false);
      }
    };

    const getReportStats = () => {
      const now = new Date();
      const filterDate = new Date();
      
      switch(dateRange) {
        case 'week':
          filterDate.setDate(now.getDate() - 7);
          break;
        case 'month':
          filterDate.setMonth(now.getMonth() - 1);
          break;
        case 'year':
          filterDate.setFullYear(now.getFullYear() - 1);
          break;
      }

      const filteredEvents = events.filter(e => new Date(e.date) >= filterDate);
      const filteredPractices = practices.filter(p => new Date(p.date) >= filterDate);

      return {
        events: filteredEvents.length,
        practices: filteredPractices.length,
        criticalEvents: filteredEvents.filter(e => e.severity === 'Critique').length,
        regions: new Set(filteredEvents.map(e => e.location.split(',')[0])).size
      };
    };

    const stats = getReportStats();

    return (
      <div className="max-w-4xl mx-auto space-y-6" data-name="reports" data-file="components/Reports.js">
        <div className="card">
          <div className="flex items-center space-x-3 mb-6">
            <div className="icon-file-text text-2xl text-purple-600"></div>
            <h2 className="text-xl sm:text-2xl font-bold text-gray-800">Rapports Automatisés</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div>
              <label className="block text-sm font-medium mb-2">Type de rapport</label>
              <select
                value={reportType}
                onChange={(e) => setReportType(e.target.value)}
                className="input-field"
              >
                <option value="events">Événements climatiques</option>
                <option value="practices">Bonnes pratiques</option>
                <option value="complete">Rapport complet</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">Période</label>
              <select
                value={dateRange}
                onChange={(e) => setDateRange(e.target.value)}
                className="input-field"
              >
                <option value="week">Dernière semaine</option>
                <option value="month">Dernier mois</option>
                <option value="year">Dernière année</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
            <div className="bg-blue-100 p-4 rounded-lg text-center">
              <div className="text-2xl font-bold text-blue-600">{stats.events}</div>
              <div className="text-sm text-blue-700">Événements</div>
            </div>
            <div className="bg-green-100 p-4 rounded-lg text-center">
              <div className="text-2xl font-bold text-green-600">{stats.practices}</div>
              <div className="text-sm text-green-700">Bonnes pratiques</div>
            </div>
            <div className="bg-red-100 p-4 rounded-lg text-center">
              <div className="text-2xl font-bold text-red-600">{stats.criticalEvents}</div>
              <div className="text-sm text-red-700">Critiques</div>
            </div>
            <div className="bg-purple-100 p-4 rounded-lg text-center">
              <div className="text-2xl font-bold text-purple-600">{stats.regions}</div>
              <div className="text-sm text-purple-700">Régions</div>
            </div>
          </div>

          <button
            onClick={generateReport}
            disabled={generating}
            className="btn-primary flex items-center space-x-2 mx-auto"
          >
            <div className={`icon-${generating ? 'loader animate-spin' : 'download'} text-lg`}></div>
            <span>{generating ? 'Génération...' : 'Télécharger le rapport'}</span>
          </button>
        </div>
      </div>
    );
  } catch (error) {
    console.error('Reports component error:', error);
    return null;
  }
}
