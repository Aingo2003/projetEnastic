function AdminDashboard({ user }) {
  try {
    const [admins, setAdmins] = React.useState([]);
    const [users, setUsers] = React.useState([]);
    const [showAddAdmin, setShowAddAdmin] = React.useState(false);
    const [newAdmin, setNewAdmin] = React.useState({
      email: '',
      role: 'admin'
    });

    React.useEffect(() => {
      loadAdmins();
      loadUsers();
    }, []);

    const loadAdmins = async () => {
      try {
        const result = await trickleListObjects('admin', 50, true);
        setAdmins(result.items);
      } catch (error) {
        console.error('Error loading admins:', error);
      }
    };

    const loadUsers = async () => {
      try {
        const result = await trickleListObjects('user', 100, true);
        setUsers(result.items);
      } catch (error) {
        console.error('Error loading users:', error);
      }
    };

    const addAdmin = async (e) => {
      e.preventDefault();
      try {
        const adminData = {
          userId: `admin-${Date.now()}`,
          email: newAdmin.email,
          role: newAdmin.role,
          permissions: JSON.stringify(['view_analytics', 'moderate_content']),
          createdAt: new Date().toISOString(),
          createdBy: user.email
        };

        await trickleCreateObject('admin', adminData);
        setNewAdmin({ email: '', role: 'admin' });
        setShowAddAdmin(false);
        loadAdmins();
        alert('Administrateur ajouté avec succès!');
      } catch (error) {
        console.error('Error adding admin:', error);
      }
    };

    return (
      <div className="max-w-6xl mx-auto space-y-6" data-name="admin-dashboard" data-file="components/AdminDashboard.js">
        <div className="card">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-3">
              <div className="icon-shield text-2xl text-blue-600"></div>
              <h2 className="text-2xl font-bold text-gray-800">Tableau de Bord Administrateur</h2>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div className="bg-blue-100 p-6 rounded-lg">
              <div className="text-2xl font-bold text-blue-600">{users.length}</div>
              <div className="text-sm text-blue-700">Utilisateurs totaux</div>
            </div>
            <div className="bg-green-100 p-6 rounded-lg">
              <div className="text-2xl font-bold text-green-600">{admins.length}</div>
              <div className="text-sm text-green-700">Administrateurs</div>
            </div>
            <div className="bg-purple-100 p-6 rounded-lg">
              <div className="text-2xl font-bold text-purple-600">Active</div>
              <div className="text-sm text-purple-700">Statut système</div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold">Administrateurs</h3>
                <button
                  onClick={() => setShowAddAdmin(!showAddAdmin)}
                  className="btn-primary flex items-center space-x-2"
                >
                  <div className="icon-plus text-sm"></div>
                  <span>Ajouter Admin</span>
                </button>
              </div>

              {showAddAdmin && (
                <div className="bg-gray-50 p-4 rounded-lg mb-4">
                  <form onSubmit={addAdmin} className="space-y-3">
                    <div>
                      <label className="block text-sm font-medium mb-1">Email</label>
                      <input
                        type="email"
                        value={newAdmin.email}
                        onChange={(e) => setNewAdmin(prev => ({...prev, email: e.target.value}))}
                        className="input-field"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1">Rôle</label>
                      <select
                        value={newAdmin.role}
                        onChange={(e) => setNewAdmin(prev => ({...prev, role: e.target.value}))}
                        className="input-field"
                      >
                        <option value="admin">Admin</option>
                        <option value="moderator">Modérateur</option>
                      </select>
                    </div>
                    <div className="flex space-x-2">
                      <button type="submit" className="btn-primary">Ajouter</button>
                      <button
                        type="button"
                        onClick={() => setShowAddAdmin(false)}
                        className="btn-secondary"
                      >
                        Annuler
                      </button>
                    </div>
                  </form>
                </div>
              )}

              <div className="space-y-2">
                {admins.map(admin => (
                  <div key={admin.objectId} className="border p-3 rounded-lg">
                    <div className="font-medium">{admin.objectData.email}</div>
                    <div className="text-sm text-gray-600">
                      Rôle: {admin.objectData.role} | 
                      Créé le {new Date(admin.objectData.createdAt).toLocaleDateString()}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <h3 className="text-lg font-semibold mb-4">Utilisateurs Récents</h3>
              <div className="space-y-2 max-h-64 overflow-y-auto">
                {users.slice(0, 10).map(user => (
                  <div key={user.objectId} className="border p-3 rounded-lg">
                    <div className="font-medium">
                      {user.objectData.firstName} {user.objectData.lastName}
                    </div>
                    <div className="text-sm text-gray-600">{user.objectData.email}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  } catch (error) {
    console.error('AdminDashboard component error:', error);
    return null;
  }
}