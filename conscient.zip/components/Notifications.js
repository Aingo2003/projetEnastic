function Notifications({ user, events }) {
  try {
    const [notifications, setNotifications] = React.useState([]);
    const [preferences, setPreferences] = React.useState({
      criticalEvents: true,
      localEvents: true,
      weeklyReports: false
    });

    React.useEffect(() => {
      generateNotifications();
    }, [events, user]);

    const generateNotifications = () => {
      const userLocation = user.location || '';
      const criticalEvents = events.filter(e => 
        e.severity === 'Critique' && 
        e.location.toLowerCase().includes(userLocation.toLowerCase().split(',')[0])
      );

      const newNotifications = criticalEvents.map(event => ({
        id: `notif-${event.id}`,
        type: 'critical',
        title: `Événement critique signalé`,
        message: `${event.type} à ${event.location}`,
        date: new Date().toISOString(),
        read: false,
        eventId: event.id
      }));

      setNotifications(prev => [...newNotifications, ...prev].slice(0, 20));
    };

    const markAsRead = (notifId) => {
      setNotifications(prev => 
        prev.map(n => n.id === notifId ? {...n, read: true} : n)
      );
    };

    const getNotificationIcon = (type) => {
      switch(type) {
        case 'critical': return 'alert-triangle';
        case 'info': return 'info';
        case 'success': return 'check-circle';
        default: return 'bell';
      }
    };

    return (
      <div className="max-w-4xl mx-auto space-y-6" data-name="notifications" data-file="components/Notifications.js">
        <div className="card">
          <div className="flex items-center space-x-3 mb-6">
            <div className="icon-bell text-2xl text-blue-600"></div>
            <h2 className="text-xl sm:text-2xl font-bold text-gray-800">Notifications</h2>
          </div>

          {/* Preferences */}
          <div className="bg-gray-50 p-4 rounded-lg mb-6">
            <h3 className="text-lg font-semibold mb-3">Préférences de notification</h3>
            <div className="space-y-3">
              <label className="flex items-center space-x-3">
                <input
                  type="checkbox"
                  checked={preferences.criticalEvents}
                  onChange={(e) => setPreferences(prev => ({...prev, criticalEvents: e.target.checked}))}
                  className="rounded"
                />
                <span className="text-sm sm:text-base">Événements critiques dans ma région</span>
              </label>
              <label className="flex items-center space-x-3">
                <input
                  type="checkbox"
                  checked={preferences.localEvents}
                  onChange={(e) => setPreferences(prev => ({...prev, localEvents: e.target.checked}))}
                  className="rounded"
                />
                <span className="text-sm sm:text-base">Tous les événements locaux</span>
              </label>
              <label className="flex items-center space-x-3">
                <input
                  type="checkbox"
                  checked={preferences.weeklyReports}
                  onChange={(e) => setPreferences(prev => ({...prev, weeklyReports: e.target.checked}))}
                  className="rounded"
                />
                <span className="text-sm sm:text-base">Rapports hebdomadaires</span>
              </label>
            </div>
          </div>

          {/* Notifications List */}
          <div className="space-y-3">
            {notifications.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <div className="icon-bell text-3xl mb-2"></div>
                <p>Aucune notification pour le moment</p>
              </div>
            ) : (
              notifications.map(notif => (
                <div
                  key={notif.id}
                  className={`border rounded-lg p-4 cursor-pointer ${notif.read ? 'bg-gray-50' : 'bg-blue-50 border-blue-200'}`}
                  onClick={() => markAsRead(notif.id)}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-start space-x-3">
                      <div className={`icon-${getNotificationIcon(notif.type)} text-lg ${notif.type === 'critical' ? 'text-red-600' : 'text-blue-600'}`}></div>
                      <div>
                        <h4 className="font-semibold text-sm sm:text-base">{notif.title}</h4>
                        <p className="text-gray-700 text-sm">{notif.message}</p>
                        <p className="text-xs text-gray-500 mt-1">
                          {new Date(notif.date).toLocaleString()}
                        </p>
                      </div>
                    </div>
                    {!notif.read && (
                      <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    );
  } catch (error) {
    console.error('Notifications component error:', error);
    return null;
  }
}