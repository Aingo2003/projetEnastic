function Training({ user }) {
  try {
    const [courses, setCourses] = React.useState([]);
    const [selectedCourse, setSelectedCourse] = React.useState(null);
    const [showCreateForm, setShowCreateForm] = React.useState(false);
    const [newCourse, setNewCourse] = React.useState({
      title: '',
      description: '',
      content: '',
      region: '',
      category: '',
      level: '',
      duration: ''
    });

    React.useEffect(() => {
      loadCourses();
    }, []);

    const loadCourses = async () => {
      try {
        const result = await trickleListObjects('course', 50, true);
        setCourses(result.items);
      } catch (error) {
        console.error('Error loading courses:', error);
      }
    };

    const createCourse = async (e) => {
      e.preventDefault();
      try {
        const courseData = {
          ...newCourse,
          createdBy: user.firstName + ' ' + user.lastName,
          createdAt: new Date().toISOString()
        };

        await trickleCreateObject('course', courseData);
        setNewCourse({
          title: '', description: '', content: '', region: '',
          category: '', level: '', duration: ''
        });
        setShowCreateForm(false);
        loadCourses();
        alert('Cours créé avec succès!');
      } catch (error) {
        console.error('Error creating course:', error);
      }
    };

    const categories = ['Agriculture', 'Eau', 'Énergie', 'Déchets', 'Biodiversité', 'Climat'];
    const levels = ['Débutant', 'Intermédiaire', 'Avancé'];

    return (
      <div className="max-w-6xl mx-auto space-y-6" data-name="training" data-file="components/Training.js">
        <div className="card">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-3">
              <div className="icon-book-open text-2xl text-purple-600"></div>
              <h2 className="text-2xl font-bold text-gray-800">Formation Environnementale</h2>
            </div>
            <button
              onClick={() => setShowCreateForm(!showCreateForm)}
              className="btn-primary flex items-center space-x-2"
            >
              <div className="icon-plus text-lg"></div>
              <span>Créer un cours</span>
            </button>
          </div>

          {showCreateForm && (
            <div className="bg-gray-50 p-6 rounded-lg mb-6">
              <h3 className="text-lg font-semibold mb-4">Nouveau Cours</h3>
              <form onSubmit={createCourse} className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-1">Titre</label>
                  <input
                    type="text"
                    value={newCourse.title}
                    onChange={(e) => setNewCourse(prev => ({...prev, title: e.target.value}))}
                    className="input-field"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">Région</label>
                  <input
                    type="text"
                    value={newCourse.region}
                    onChange={(e) => setNewCourse(prev => ({...prev, region: e.target.value}))}
                    className="input-field"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">Catégorie</label>
                  <select
                    value={newCourse.category}
                    onChange={(e) => setNewCourse(prev => ({...prev, category: e.target.value}))}
                    className="input-field"
                    required
                  >
                    <option value="">Sélectionner</option>
                    {categories.map(cat => (
                      <option key={cat} value={cat}>{cat}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">Niveau</label>
                  <select
                    value={newCourse.level}
                    onChange={(e) => setNewCourse(prev => ({...prev, level: e.target.value}))}
                    className="input-field"
                    required
                  >
                    <option value="">Sélectionner</option>
                    {levels.map(level => (
                      <option key={level} value={level}>{level}</option>
                    ))}
                  </select>
                </div>
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium mb-1">Description</label>
                  <textarea
                    value={newCourse.description}
                    onChange={(e) => setNewCourse(prev => ({...prev, description: e.target.value}))}
                    className="input-field h-24"
                    required
                  ></textarea>
                </div>
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium mb-1">Contenu du cours</label>
                  <textarea
                    value={newCourse.content}
                    onChange={(e) => setNewCourse(prev => ({...prev, content: e.target.value}))}
                    className="input-field h-32"
                    required
                  ></textarea>
                </div>
                <div className="md:col-span-2 flex space-x-3">
                  <button type="submit" className="btn-primary">Créer le cours</button>
                  <button
                    type="button"
                    onClick={() => setShowCreateForm(false)}
                    className="btn-secondary"
                  >
                    Annuler
                  </button>
                </div>
              </form>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {courses.map(course => (
              <div
                key={course.objectId}
                className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow cursor-pointer"
                onClick={() => setSelectedCourse(course)}
              >
                <div className="flex items-start justify-between mb-2">
                  <h3 className="font-semibold text-gray-800">{course.objectData.title}</h3>
                  <span className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded">
                    {course.objectData.level}
                  </span>
                </div>
                <p className="text-sm text-gray-600 mb-3">{course.objectData.description}</p>
                <div className="text-xs text-gray-500">
                  <div>📍 {course.objectData.region}</div>
                  <div>📚 {course.objectData.category}</div>
                  <div>⏱️ {course.objectData.duration}</div>
                </div>
              </div>
            ))}
          </div>

          {selectedCourse && (
            <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
              <div className="bg-white rounded-lg p-6 max-w-2xl w-full max-h-96 overflow-y-auto">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-xl font-bold">{selectedCourse.objectData.title}</h3>
                  <button
                    onClick={() => setSelectedCourse(null)}
                    className="text-gray-500 hover:text-gray-700"
                  >
                    <div className="icon-x text-lg"></div>
                  </button>
                </div>
                <div className="space-y-4">
                  <div>
                    <strong>Description:</strong>
                    <p className="mt-1">{selectedCourse.objectData.description}</p>
                  </div>
                  <div>
                    <strong>Contenu:</strong>
                    <p className="mt-1 whitespace-pre-wrap">{selectedCourse.objectData.content}</p>
                  </div>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div><strong>Région:</strong> {selectedCourse.objectData.region}</div>
                    <div><strong>Catégorie:</strong> {selectedCourse.objectData.category}</div>
                    <div><strong>Niveau:</strong> {selectedCourse.objectData.level}</div>
                    <div><strong>Durée:</strong> {selectedCourse.objectData.duration}</div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    );
  } catch (error) {
    console.error('Training component error:', error);
    return null;
  }
}