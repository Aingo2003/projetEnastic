function Analytics({ events, practices }) {
  try {
    const [chartInstances, setChartInstances] = React.useState({});
    
    React.useEffect(() => {
      createCharts();
      return () => {
        // Cleanup charts
        Object.values(chartInstances).forEach(chart => {
          if (chart) chart.destroy();
        });
      };
    }, [events, practices]);

    const createCharts = () => {
      createEventTypeChart();
      createRegionChart();
      createTimelineChart();
    };

    const createEventTypeChart = () => {
      const ctx = document.getElementById('eventTypeChart');
      if (!ctx) return;

      const eventCounts = events.reduce((acc, event) => {
        acc[event.type] = (acc[event.type] || 0) + 1;
        return acc;
      }, {});

      new ChartJS(ctx, {
        type: 'doughnut',
        data: {
          labels: Object.keys(eventCounts),
          datasets: [{
            data: Object.values(eventCounts),
            backgroundColor: ['#ef4444', '#3b82f6', '#f59e0b', '#10b981', '#8b5cf6']
          }]
        },
        options: {
          responsive: true,
          plugins: { legend: { display: false } }
        }
      });
    };

    const createRegionChart = () => {
      const ctx = document.getElementById('regionChart');
      if (!ctx) return;

      const regionCounts = events.reduce((acc, event) => {
        const region = event.location.split(',')[0];
        acc[region] = (acc[region] || 0) + 1;
        return acc;
      }, {});

      new ChartJS(ctx, {
        type: 'bar',
        data: {
          labels: Object.keys(regionCounts),
          datasets: [{
            label: 'Événements par région',
            data: Object.values(regionCounts),
            backgroundColor: '#3b82f6'
          }]
        },
        options: {
          responsive: true,
          plugins: { legend: { display: false } }
        }
      });
    };

    const createTimelineChart = () => {
      const ctx = document.getElementById('timelineChart');
      if (!ctx) return;

      const monthCounts = events.reduce((acc, event) => {
        const month = new Date(event.date).toLocaleDateString('fr-FR', { month: 'short' });
        acc[month] = (acc[month] || 0) + 1;
        return acc;
      }, {});

      new ChartJS(ctx, {
        type: 'line',
        data: {
          labels: Object.keys(monthCounts),
          datasets: [{
            label: 'Évolution temporelle',
            data: Object.values(monthCounts),
            borderColor: '#10b981',
            backgroundColor: 'rgba(16, 185, 129, 0.1)',
            fill: true
          }]
        },
        options: {
          responsive: true,
          plugins: { legend: { display: false } }
        }
      });
    };

    return (
      <div className="max-w-6xl mx-auto space-y-6" data-name="analytics" data-file="components/Analytics.js">
        <div className="card">
          <div className="flex items-center space-x-3 mb-6">
            <div className="icon-bar-chart text-2xl text-green-600"></div>
            <h2 className="text-2xl font-bold text-gray-800">Analytiques Environnementales</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <div className="card">
              <h3 className="text-lg font-semibold mb-4">Types d'Événements</h3>
              <canvas id="eventTypeChart" width="400" height="400"></canvas>
            </div>

            <div className="card">
              <h3 className="text-lg font-semibold mb-4">Événements par Région</h3>
              <canvas id="regionChart" width="400" height="400"></canvas>
            </div>

            <div className="card">
              <h3 className="text-lg font-semibold mb-4">Évolution Temporelle</h3>
              <canvas id="timelineChart" width="400" height="400"></canvas>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6">
            <div className="bg-red-100 p-4 rounded-lg">
              <div className="text-2xl font-bold text-red-600">{events.length}</div>
              <div className="text-sm text-red-700">Total Événements</div>
            </div>
            <div className="bg-blue-100 p-4 rounded-lg">
              <div className="text-2xl font-bold text-blue-600">{practices.length}</div>
              <div className="text-sm text-blue-700">Bonnes Pratiques</div>
            </div>
            <div className="bg-green-100 p-4 rounded-lg">
              <div className="text-2xl font-bold text-green-600">
                {new Set(events.map(e => e.location.split(',')[0])).size}
              </div>
              <div className="text-sm text-green-700">Régions Couvertes</div>
            </div>
          </div>
        </div>
      </div>
    );
  } catch (error) {
    console.error('Analytics component error:', error);
    return null;
  }
}