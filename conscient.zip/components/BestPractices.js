function BestPractices({ practices, onAddPractice, user }) {
  try {
    const [showForm, setShowForm] = React.useState(false);
    const [formData, setFormData] = React.useState({
      title: '',
      description: ''
    });

    const handleSubmit = (e) => {
      e.preventDefault();
      onAddPractice(formData);
      setFormData({ title: '', description: '' });
      setShowForm(false);
    };

    const handleChange = (e) => {
      setFormData(prev => ({
        ...prev,
        [e.target.name]: e.target.value
      }));
    };

    const sendEmailNotification = async (practice) => {
      // Simulate email notification
      console.log('Envoi de notification email pour:', practice.title);
      alert(`Notification envoyée aux utilisateurs pour: "${practice.title}"`);
    };

    return (
      <div className="max-w-4xl mx-auto space-y-6" data-name="best-practices" data-file="components/BestPractices.js">
        <div className="card">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-3">
              <div className="icon-lightbulb text-2xl text-yellow-600"></div>
              <h2 className="text-2xl font-bold text-gray-800">Bonnes Pratiques Environnementales</h2>
            </div>
            <button
              onClick={() => setShowForm(!showForm)}
              className="btn-primary flex items-center space-x-2"
            >
              <div className="icon-plus text-lg"></div>
              <span>Partager une pratique</span>
            </button>
          </div>

          {showForm && (
            <div className="bg-gray-50 p-6 rounded-lg mb-6">
              <h3 className="text-lg font-semibold mb-4">Partager une bonne pratique</h3>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Titre</label>
                  <input
                    type="text"
                    name="title"
                    value={formData.title}
                    onChange={handleChange}
                    className="input-field"
                    placeholder="Ex: Techniques de compostage domestique"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Description</label>
                  <textarea
                    name="description"
                    value={formData.description}
                    onChange={handleChange}
                    className="input-field h-24 resize-none"
                    placeholder="Décrivez la pratique, ses avantages et comment l'appliquer..."
                    required
                  ></textarea>
                </div>
                <div className="flex space-x-3">
                  <button type="submit" className="btn-primary">
                    Publier
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowForm(false)}
                    className="btn-secondary"
                  >
                    Annuler
                  </button>
                </div>
              </form>
            </div>
          )}

          <div className="space-y-4">
            {practices.map(practice => (
              <div key={practice.id} className="border border-gray-200 rounded-lg p-6">
                <div className="flex items-start justify-between mb-3">
                  <h3 className="text-lg font-semibold text-gray-800">{practice.title}</h3>
                  <button
                    onClick={() => sendEmailNotification(practice)}
                    className="text-blue-600 hover:text-blue-700 text-sm flex items-center space-x-1"
                  >
                    <div className="icon-mail text-sm"></div>
                    <span>Notifier</span>
                  </button>
                </div>
                <p className="text-gray-700 mb-4">{practice.description}</p>
                <div className="flex items-center justify-between text-sm text-gray-500">
                  <span>Par {practice.author} le {practice.date}</span>
                  <div className="flex items-center space-x-4">
                    <div className="flex items-center space-x-1">
                      <div className="icon-heart text-red-500"></div>
                      <span>{practice.likes} likes</span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  } catch (error) {
    console.error('BestPractices component error:', error);
    return null;
  }
}