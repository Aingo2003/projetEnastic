// Geolocation utilities for automatic location detection

function getCurrentPosition() {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      reject(new Error('Geolocation is not supported by this browser.'));
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        resolve({
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
          accuracy: position.coords.accuracy
        });
      },
      (error) => {
        let errorMessage;
        switch(error.code) {
          case error.PERMISSION_DENIED:
            errorMessage = "L'utilisateur a refusé la demande de géolocalisation.";
            break;
          case error.POSITION_UNAVAILABLE:
            errorMessage = "Les informations de localisation ne sont pas disponibles.";
            break;
          case error.TIMEOUT:
            errorMessage = "La demande de géolocalisation a expiré.";
            break;
          default:
            errorMessage = "Une erreur inconnue s'est produite.";
            break;
        }
        reject(new Error(errorMessage));
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 60000
      }
    );
  });
}

async function getAddressFromCoordinates(lat, lng) {
  try {
    // Simulate reverse geocoding - in real app, use Google Maps Geocoding API
    const response = await fetch(
      `https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=${lat}&longitude=${lng}&localityLanguage=fr`
    );
    
    if (response.ok) {
      const data = await response.json();
      return {
        city: data.city || data.locality || 'Ville inconnue',
        region: data.principalSubdivision || 'Région inconnue',
        country: data.countryName || 'Pays inconnu',
        fullAddress: data.locality ? 
          `${data.locality}, ${data.principalSubdivision}, ${data.countryName}` :
          `${data.principalSubdivision}, ${data.countryName}`
      };
    } else {
      throw new Error('Impossible de récupérer l\'adresse');
    }
  } catch (error) {
    console.error('Error getting address:', error);
    return {
      city: 'Ville inconnue',
      region: 'Région inconnue', 
      country: 'Pays inconnu',
      fullAddress: 'Adresse inconnue'
    };
  }
}

function watchPosition(callback, errorCallback) {
  if (!navigator.geolocation) {
    errorCallback(new Error('Geolocation is not supported'));
    return null;
  }

  return navigator.geolocation.watchPosition(
    callback,
    errorCallback,
    {
      enableHighAccuracy: true,
      timeout: 5000,
      maximumAge: 30000
    }
  );
}

function clearWatch(watchId) {
  if (watchId && navigator.geolocation) {
    navigator.geolocation.clearWatch(watchId);
  }
}
