// AI Agent for environmental recommendations

async function generateEnvironmentalRecommendations(userLocation, events, practices) {
  try {
    const systemPrompt = `Tu es un expert en environnement et changement climatique. 
    Ton rôle est de générer des recommandations personnalisées basées sur la localisation 
    de l'utilisateur et les événements climatiques signalés dans sa région.

    Données disponibles:
    - Localisation: ${userLocation}
    - Événements récents: ${JSON.stringify(events.slice(0, 5))}
    - Bonnes pratiques existantes: ${JSON.stringify(practices.slice(0, 3))}

    Génère 3-4 recommandations spécifiques et actionables en français, 
    sous format JSON avec les champs: title, description, priority (Haute/Moyenne/Faible), category.`;

    const userPrompt = `Génère des recommandations environnementales personnalisées pour cette région.`;
    
    const response = await invokeAIAgent(systemPrompt, userPrompt);
    
    // Clean response and parse JSON
    let cleanResponse = response.replace(/```json/g, '').replace(/```/g, '').trim();
    
    try {
      return JSON.parse(cleanResponse);
    } catch (parseError) {
      // Fallback recommendations if parsing fails
      return [
        {
          title: "Surveillance des événements climatiques",
          description: "Continuez à signaler les changements environnementaux observés dans votre région",
          priority: "Haute",
          category: "Surveillance"
        },
        {
          title: "Pratiques d'adaptation locale",
          description: "Adoptez des techniques agricoles adaptées aux conditions climatiques de votre région",
          priority: "Moyenne",
          category: "Agriculture"
        }
      ];
    }
  } catch (error) {
    console.error('Error generating recommendations:', error);
    return [];
  }
}

async function generateCollaborationSuggestions(userLocation, events) {
  try {
    const systemPrompt = `Tu es un facilitateur de projets environnementaux collaboratifs.
    Analyse les événements climatiques signalés et suggère des projets de collaboration
    entre utilisateurs pour résoudre ces problèmes.

    Événements dans la région: ${JSON.stringify(events)}
    Localisation: ${userLocation}

    Génère 2-3 suggestions de projets collaboratifs en français, format JSON avec:
    title, description, participants_needed, duration, impact_expected.`;

    const userPrompt = `Suggère des projets collaboratifs pour cette région.`;
    
    const response = await invokeAIAgent(systemPrompt, userPrompt);
    let cleanResponse = response.replace(/```json/g, '').replace(/```/g, '').trim();
    
    try {
      return JSON.parse(cleanResponse);
    } catch (parseError) {
      return [
        {
          title: "Groupe de surveillance environnementale",
          description: "Former un groupe pour surveiller et signaler les changements environnementaux",
          participants_needed: "5-10 personnes",
          duration: "Ongoing",
          impact_expected: "Amélioration du suivi environnemental local"
        }
      ];
    }
  } catch (error) {
    console.error('Error generating collaboration suggestions:', error);
    return [];
  }
}