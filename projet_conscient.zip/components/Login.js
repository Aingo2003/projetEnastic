function Login({ onLogin }) {
  try {
    const [isRegistering, setIsRegistering] = React.useState(false);
    const [formData, setFormData] = React.useState({
      firstName: '',
      lastName: '',
      email: '',
      password: '',
      profilePhoto: ''
    });

    const handleSubmit = (e) => {
      e.preventDefault();
      if (isRegistering) {
        // Registration logic
        onLogin(formData);
      } else {
        // Login logic - for demo, just use form data
        onLogin(formData);
      }
    };

    const handleChange = (e) => {
      setFormData(prev => ({
        ...prev,
        [e.target.name]: e.target.value
      }));
    };

    return (
      <div className="max-w-md mx-auto mt-16" data-name="login" data-file="components/Login.js">
        <div className="card">
          <div className="text-center mb-6">
            <div className="icon-leaf text-4xl text-green-600 mx-auto mb-4"></div>
            <h2 className="text-2xl font-bold text-gray-800">
              {isRegistering ? 'Inscription' : 'Connexion'}
            </h2>
            <p className="text-gray-600 mt-2">
              {isRegistering ? 'Créez votre compte EcoWatch' : 'Accédez à votre compte'}
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {isRegistering && (
              <>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Prénom</label>
                  <input
                    type="text"
                    name="firstName"
                    value={formData.firstName}
                    onChange={handleChange}
                    className="input-field"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Nom</label>
                  <input
                    type="text"
                    name="lastName"
                    value={formData.lastName}
                    onChange={handleChange}
                    className="input-field"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Photo de profil (URL)</label>
                  <input
                    type="url"
                    name="profilePhoto"
                    value={formData.profilePhoto}
                    onChange={handleChange}
                    className="input-field"
                    placeholder="https://example.com/photo.jpg"
                  />
                </div>
              </>
            )}
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                className="input-field"
                required
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Mot de passe</label>
              <input
                type="password"
                name="password"
                value={formData.password}
                onChange={handleChange}
                className="input-field"
                required
              />
            </div>

            <button type="submit" className="btn-primary w-full">
              {isRegistering ? 'S\'inscrire' : 'Se connecter'}
            </button>
          </form>

          <div className="mt-6 text-center">
            <button
              onClick={() => setIsRegistering(!isRegistering)}
              className="text-green-600 hover:text-green-700 text-sm"
            >
              {isRegistering ? 'Déjà un compte ? Se connecter' : 'Pas de compte ? S\'inscrire'}
            </button>
          </div>
        </div>
      </div>
    );
  } catch (error) {
    console.error('Login component error:', error);
    return null;
  }
}