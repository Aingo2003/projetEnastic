function Header({ user, currentPage, setCurrentPage, onLogout, isAdmin }) {
  try {
    return (
      <header className="bg-white shadow-md" data-name="header" data-file="components/Header.js">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="icon-leaf text-2xl text-green-600"></div>
              <h1 className="text-2xl font-bold text-green-700">EcoWatch</h1>
            </div>
            
            {user && (
              <nav className="hidden md:flex items-center space-x-6">
                <button
                  onClick={() => setCurrentPage('dashboard')}
                  className={`px-3 py-2 rounded-md ${currentPage === 'dashboard' ? 'bg-green-100 text-green-700' : 'text-gray-600 hover:text-green-600'}`}
                >
                  Tableau de bord
                </button>
                <button
                  onClick={() => setCurrentPage('report')}
                  className={`px-3 py-2 rounded-md ${currentPage === 'report' ? 'bg-green-100 text-green-700' : 'text-gray-600 hover:text-green-600'}`}
                >
                  Signaler
                </button>
                <button
                  onClick={() => setCurrentPage('map')}
                  className={`px-3 py-2 rounded-md ${currentPage === 'map' ? 'bg-green-100 text-green-700' : 'text-gray-600 hover:text-green-600'}`}
                >
                  Carte
                </button>
                <button
                  onClick={() => setCurrentPage('practices')}
                  className={`px-3 py-2 rounded-md ${currentPage === 'practices' ? 'bg-green-100 text-green-700' : 'text-gray-600 hover:text-green-600'}`}
                >
                  Bonnes pratiques
                </button>
                <button
                  onClick={() => setCurrentPage('recommendations')}
                  className={`px-3 py-2 rounded-md ${currentPage === 'recommendations' ? 'bg-green-100 text-green-700' : 'text-gray-600 hover:text-green-600'}`}
                >
                  Recommandations IA
                </button>
                <button
                  onClick={() => setCurrentPage('messages')}
                  className={`px-3 py-2 rounded-md ${currentPage === 'messages' ? 'bg-green-100 text-green-700' : 'text-gray-600 hover:text-green-600'}`}
                >
                  Messages
                </button>
                <button
                  onClick={() => setCurrentPage('training')}
                  className={`px-3 py-2 rounded-md ${currentPage === 'training' ? 'bg-green-100 text-green-700' : 'text-gray-600 hover:text-green-600'}`}
                >
                  Formation
                </button>
                {isAdmin && (
                  <>
                    <button
                      onClick={() => setCurrentPage('admin')}
                      className={`px-3 py-2 rounded-md ${currentPage === 'admin' ? 'bg-blue-100 text-blue-700' : 'text-gray-600 hover:text-blue-600'}`}
                    >
                      Admin
                    </button>
                    <button
                      onClick={() => setCurrentPage('analytics')}
                      className={`px-3 py-2 rounded-md ${currentPage === 'analytics' ? 'bg-blue-100 text-blue-700' : 'text-gray-600 hover:text-blue-600'}`}
                    >
                      Analytics
                    </button>
                  </>
                )}
              </nav>
            )}
            
            {user && (
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-2">
                  <img 
                    src={user.profilePhoto || 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=40&h=40&fit=crop&crop=face'} 
                    alt="Profile" 
                    className="w-8 h-8 rounded-full"
                  />
                  <span className="text-sm font-medium text-gray-700">{user.firstName}</span>
                </div>
                <button
                  onClick={onLogout}
                  className="text-gray-500 hover:text-red-600"
                >
                  <div className="icon-log-out text-lg"></div>
                </button>
              </div>
            )}
          </div>
        </div>
      </header>
    );
  } catch (error) {
    console.error('Header component error:', error);
    return null;
  }
}