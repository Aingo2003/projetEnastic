function EventMap({ events }) {
  try {
    const mapRef = React.useRef(null);
    const [selectedEvent, setSelectedEvent] = React.useState(null);

    React.useEffect(() => {
      // Simulate Google Maps integration
      // In a real app, you would load Google Maps API here
      console.log('Google Maps would be initialized here with events:', events);
    }, [events]);

    const getEventTypeColor = (type) => {
      const colors = {
        'Désertification': 'bg-yellow-500',
        'Inondation': 'bg-blue-500',
        'Érosion': 'bg-orange-500',
        'Sécheresse': 'bg-red-500',
        'Déforestation': 'bg-green-500',
        'Pollution': 'bg-purple-500',
        'Autre': 'bg-gray-500'
      };
      return colors[type] || 'bg-gray-500';
    };

    return (
      <div className="space-y-6" data-name="event-map" data-file="components/EventMap.js">
        <div className="card">
          <div className="flex items-center space-x-3 mb-6">
            <div className="icon-map text-2xl text-blue-600"></div>
            <h2 className="text-2xl font-bold text-gray-800">Carte des Événements Climatiques</h2>
          </div>

          {/* Placeholder for Google Maps */}
          <div className="bg-gray-100 h-96 rounded-lg flex items-center justify-center mb-6">
            <div className="text-center">
              <div className="icon-map-pin text-4xl text-gray-400 mb-2"></div>
              <p className="text-gray-600">Carte Google Maps</p>
              <p className="text-sm text-gray-500">Intégration API Google Maps ici</p>
            </div>
          </div>

          {/* Legend */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {['Désertification', 'Inondation', 'Érosion', 'Sécheresse'].map(type => (
              <div key={type} className="flex items-center space-x-2">
                <div className={`w-3 h-3 rounded-full ${getEventTypeColor(type)}`}></div>
                <span className="text-sm text-gray-700">{type}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Events List */}
        <div className="card">
          <h3 className="text-lg font-bold text-gray-800 mb-4">Événements Récents</h3>
          <div className="space-y-4">
            {events.map(event => (
              <div 
                key={event.id} 
                className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow cursor-pointer"
                onClick={() => setSelectedEvent(selectedEvent === event.id ? null : event.id)}
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-start space-x-3">
                    <div className={`w-4 h-4 rounded-full ${getEventTypeColor(event.type)} mt-1`}></div>
                    <div>
                      <h4 className="font-semibold text-gray-800">{event.type}</h4>
                      <p className="text-sm text-gray-600">{event.location}</p>
                      <p className="text-xs text-gray-500">Signalé par {event.reportedBy} le {event.date}</p>
                    </div>
                  </div>
                  <div className="icon-chevron-down text-gray-400"></div>
                </div>
                
                {selectedEvent === event.id && (
                  <div className="mt-4 pt-4 border-t border-gray-200">
                    <p className="text-gray-700">{event.description}</p>
                    <div className="mt-2 text-xs text-gray-500">
                      Coordonnées: {event.lat}, {event.lng}
                    </div>
                  </div>
                )}
              </div>
            ))}
            
            {events.length === 0 && (
              <div className="text-center py-8 text-gray-500">
                <div className="icon-map-pin text-3xl mb-2"></div>
                <p>Aucun événement signalé pour le moment</p>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  } catch (error) {
    console.error('EventMap component error:', error);
    return null;
  }
}
