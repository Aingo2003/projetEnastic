function AIRecommendations({ user, events, practices }) {
  try {
    const [recommendations, setRecommendations] = React.useState([]);
    const [collaborations, setCollaborations] = React.useState([]);
    const [loading, setLoading] = React.useState(false);

    React.useEffect(() => {
      loadRecommendations();
    }, [user, events]);

    const loadRecommendations = async () => {
      setLoading(true);
      try {
        const userLocation = user.location || 'Région non spécifiée';
        const localEvents = events.filter(e => 
          e.location.toLowerCase().includes(userLocation.toLowerCase().split(',')[0]) ||
          userLocation.toLowerCase().includes(e.location.toLowerCase().split(',')[0])
        );

        const recs = await generateEnvironmentalRecommendations(userLocation, localEvents, practices);
        const collabs = await generateCollaborationSuggestions(userLocation, localEvents);
        
        setRecommendations(Array.isArray(recs) ? recs : [recs]);
        setCollaborations(Array.isArray(collabs) ? collabs : [collabs]);
      } catch (error) {
        console.error('Error loading recommendations:', error);
      } finally {
        setLoading(false);
      }
    };

    const getPriorityColor = (priority) => {
      switch(priority) {
        case 'Haute': return 'bg-red-100 text-red-800';
        case 'Moyenne': return 'bg-yellow-100 text-yellow-800';
        case 'Faible': return 'bg-green-100 text-green-800';
        default: return 'bg-gray-100 text-gray-800';
      }
    };

    return (
      <div className="max-w-4xl mx-auto space-y-6" data-name="ai-recommendations" data-file="components/AIRecommendations.js">
        <div className="card">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-3">
              <div className="icon-brain text-2xl text-purple-600"></div>
              <h2 className="text-2xl font-bold text-gray-800">Recommandations IA Personnalisées</h2>
            </div>
            <button
              onClick={loadRecommendations}
              className="btn-primary flex items-center space-x-2"
              disabled={loading}
            >
              <div className="icon-refresh-cw text-lg"></div>
              <span>{loading ? 'Génération...' : 'Actualiser'}</span>
            </button>
          </div>

          {loading && (
            <div className="text-center py-8">
              <div className="icon-loader text-3xl text-gray-400 animate-spin mb-2"></div>
              <p className="text-gray-600">Génération de recommandations personnalisées...</p>
            </div>
          )}

          {!loading && recommendations.length > 0 && (
            <div className="space-y-4 mb-8">
              <h3 className="text-lg font-semibold text-gray-800">Recommandations Environnementales</h3>
              {recommendations.map((rec, index) => (
                <div key={index} className="border border-gray-200 rounded-lg p-4">
                  <div className="flex items-start justify-between mb-2">
                    <h4 className="font-semibold text-gray-800">{rec.title}</h4>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${getPriorityColor(rec.priority)}`}>
                      {rec.priority}
                    </span>
                  </div>
                  <p className="text-gray-700 mb-2">{rec.description}</p>
                  <div className="text-sm text-gray-500">
                    Catégorie: {rec.category}
                  </div>
                </div>
              ))}
            </div>
          )}

          {!loading && collaborations.length > 0 && (
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-gray-800">Projets Collaboratifs Suggérés</h3>
              {collaborations.map((collab, index) => (
                <div key={index} className="border border-gray-200 rounded-lg p-4 bg-blue-50">
                  <h4 className="font-semibold text-gray-800 mb-2">{collab.title}</h4>
                  <p className="text-gray-700 mb-3">{collab.description}</p>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-2 text-sm text-gray-600">
                    <div>👥 {collab.participants_needed}</div>
                    <div>⏱️ {collab.duration}</div>
                    <div>🎯 {collab.impact_expected}</div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    );
  } catch (error) {
    console.error('AIRecommendations component error:', error);
    return null;
  }
}