function CommunityGroups({ user }) {
  try {
    const [groups, setGroups] = React.useState([]);
    const [showCreateForm, setShowCreateForm] = React.useState(false);
    const [selectedGroup, setSelectedGroup] = React.useState(null);
    const [newGroup, setNewGroup] = React.useState({
      name: '',
      description: '',
      region: '',
      projectType: '',
      maxMembers: ''
    });

    React.useEffect(() => {
      loadGroups();
    }, []);

    const loadGroups = async () => {
      try {
        const result = await trickleListObjects('group', 50, true);
        setGroups(result.items || []);
      } catch (error) {
        console.error('Error loading groups:', error);
        // Fallback sample data
        setGroups([
          {
            objectId: '1',
            objectData: {
              name: 'Reforestation Dakar',
              description: 'Groupe local pour replanter des arbres',
              region: 'Dakar',
              projectType: 'Reforestation',
              members: 12,
              maxMembers: 20,
              createdBy: 'Marie Sow'
            }
          }
        ]);
      }
    };

    const createGroup = async (e) => {
      e.preventDefault();
      try {
        const groupData = {
          name: newGroup.name,
          description: newGroup.description,
          region: newGroup.region,
          projectType: newGroup.projectType,
          maxMembers: parseInt(newGroup.maxMembers),
          members: 1,
          createdBy: user.firstName + ' ' + user.lastName,
          createdAt: new Date().toISOString()
        };

        const savedGroup = await trickleCreateObject('group', groupData);
        setGroups(prev => [...prev, savedGroup]);
        setNewGroup({ name: '', description: '', region: '', projectType: '', maxMembers: '' });
        setShowCreateForm(false);
        alert('Groupe créé avec succès!');
      } catch (error) {
        console.error('Error creating group:', error);
        alert('Erreur lors de la création du groupe');
      }
    };

    const joinGroup = (groupId) => {
      alert(`Demande d'adhésion envoyée pour le groupe!`);
    };

    const projectTypes = ['Reforestation', 'Nettoyage', 'Sensibilisation', 'Protection', 'Recherche'];

    return (
      <div className="max-w-6xl mx-auto space-y-6" data-name="community-groups" data-file="components/CommunityGroups.js">
        <div className="card">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-3">
              <div className="icon-users text-2xl text-indigo-600"></div>
              <h2 className="text-xl sm:text-2xl font-bold text-gray-800">Groupes Communautaires</h2>
            </div>
            <button
              onClick={() => setShowCreateForm(!showCreateForm)}
              className="btn-primary flex items-center space-x-2"
            >
              <div className="icon-plus text-lg"></div>
              <span>Créer un groupe</span>
            </button>
          </div>

          {showCreateForm && (
            <div className="bg-gray-50 p-4 sm:p-6 rounded-lg mb-6">
              <h3 className="text-lg font-semibold mb-4">Nouveau Groupe</h3>
              <form onSubmit={createGroup} className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-1">Nom du groupe</label>
                  <input
                    type="text"
                    value={newGroup.name}
                    onChange={(e) => setNewGroup(prev => ({...prev, name: e.target.value}))}
                    className="input-field"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">Région</label>
                  <input
                    type="text"
                    value={newGroup.region}
                    onChange={(e) => setNewGroup(prev => ({...prev, region: e.target.value}))}
                    className="input-field"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">Type de projet</label>
                  <select
                    value={newGroup.projectType}
                    onChange={(e) => setNewGroup(prev => ({...prev, projectType: e.target.value}))}
                    className="input-field"
                    required
                  >
                    <option value="">Sélectionner</option>
                    {projectTypes.map(type => (
                      <option key={type} value={type}>{type}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-1">Nombre max de membres</label>
                  <input
                    type="number"
                    value={newGroup.maxMembers}
                    onChange={(e) => setNewGroup(prev => ({...prev, maxMembers: e.target.value}))}
                    className="input-field"
                    min="5"
                    max="100"
                    required
                  />
                </div>
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium mb-1">Description</label>
                  <textarea
                    value={newGroup.description}
                    onChange={(e) => setNewGroup(prev => ({...prev, description: e.target.value}))}
                    className="input-field h-24"
                    required
                  ></textarea>
                </div>
                <div className="md:col-span-2 flex flex-wrap gap-3">
                  <button type="submit" className="btn-primary">Créer le groupe</button>
                  <button
                    type="button"
                    onClick={() => setShowCreateForm(false)}
                    className="btn-secondary"
                  >
                    Annuler
                  </button>
                </div>
              </form>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {groups.map(group => (
              <div key={group.objectId} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                <div className="flex items-start justify-between mb-3">
                  <h3 className="font-semibold text-gray-800 text-sm sm:text-base">{group.objectData.name}</h3>
                  <span className="text-xs bg-indigo-100 text-indigo-800 px-2 py-1 rounded">
                    {group.objectData.projectType}
                  </span>
                </div>
                <p className="text-gray-600 text-sm mb-3">{group.objectData.description}</p>
                <div className="space-y-2 text-xs sm:text-sm text-gray-500">
                  <div className="flex items-center space-x-1">
                    <div className="icon-map-pin text-sm"></div>
                    <span>{group.objectData.region}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <div className="icon-users text-sm"></div>
                    <span>{group.objectData.members}/{group.objectData.maxMembers} membres</span>
                  </div>
                </div>
                <div className="mt-4 flex flex-wrap gap-2">
                  <button
                    onClick={() => joinGroup(group.objectId)}
                    className="btn-primary text-xs px-3 py-1"
                  >
                    Rejoindre
                  </button>
                  <button
                    onClick={() => setSelectedGroup(group)}
                    className="btn-secondary text-xs px-3 py-1"
                  >
                    Détails
                  </button>